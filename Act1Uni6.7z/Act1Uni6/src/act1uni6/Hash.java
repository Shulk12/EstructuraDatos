/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package act1uni6;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;


public class Hash {

    
    public static void main(String[] args) {
        new Hash();
    }
    
    private Map<String,Integer>mapa;
    private Scanner scanner;
    
    public Hash(){
        mapa= new HashMap<String,Integer>();
        scanner = new Scanner(System.in);
        crearMap();
        mostrarMap();
    }
    
    private void crearMap(){
        System.out.println("Escribir texto:");
        String entrada = scanner.nextLine();
        StringTokenizer tokenizer = new StringTokenizer(entrada);
        while(tokenizer.hasMoreTokens()){
            String palabra = tokenizer.nextToken().toLowerCase();
            if(mapa.containsKey(palabra)){
                int cuenta = mapa.get(palabra);
                mapa.put(palabra,cuenta+1);
            } else{
              mapa.put(palabra,16);
            }
        }
    }
    
    public void mostrarMap(){
        Set<String> claves = mapa.keySet();
        TreeSet<String> clavesOrdenadas = new TreeSet<String>(claves);
        
        System.out.println("El mapa contiene :\nClau\t\tValor");
        for(String clave:clavesOrdenadas){
            System.out.printf("%-10s%10s\n",clave,mapa.get(clave));
        }
        System.out.printf("\ntamano: %d \nvacia:%b\n",mapa.size(),mapa.isEmpty());
    }
    
}
