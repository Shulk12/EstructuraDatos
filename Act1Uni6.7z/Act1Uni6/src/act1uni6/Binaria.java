/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package act1uni6;

import java.util.Arrays;


public class Binaria{

   
    public static void main(String[] args) {
        int num[]={8,10,15,20,25,30,33,41};
 
        System.out.println("Se usa metodo binarySearch:"+Arrays.binarySearch(num,25));
        
        int num2[]=Arrays.copyOf(num,4);
        System.out.append("Metodo copyOf");
        
        muestraArray(num2);
        int num3[]=Arrays.copyOfRange(num,2,6);
        System.out.println("Es el metodo copyOfRange");
        muestraArray(num3);
        
        System.out.println("Se aplica metodo equals:"+Arrays.equals(num,num2));
        System.out.println("Se aplica metodo fill");
        
        Arrays.fill(num3, 5);
        muestraArray(num3);
        
        System.out.println("Aplica metodo toString");
        System.out.println(Arrays.toString(num));

}
    
    public static void muestraArray(int num[]){
        for(int i=0;i<num.length;i++){
            System.out.println(num[i]);
        }
    }
    
}
