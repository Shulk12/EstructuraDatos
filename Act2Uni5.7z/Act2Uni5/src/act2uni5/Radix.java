/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package act2uni5;

import java.util.Scanner;

public class Radix {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada=new Scanner(System.in);
        System.out.println("cuantos numeros quiere ordenar? ");
        int n=entrada.nextInt();
        int vector[]=new int [n];
        int matriz[][]=new int [10][20];
        for(int i=0;i<n;i++){
            System.out.println("Escribe un numero: ");
            vector[i]=entrada.nextInt();
        }
        int a;
        int col=0;
        for(int i=0;i<n;i++){
            a=vector[i]%10;
            if(matriz[a][col]==0)matriz[a][col]=vector[i];
        else{
                col++;
                matriz[a][col]=vector[i];
                }
    }
        int i=0;
        for(int f=0;f<10;f++){
            for(int c=0;c<20;c++){
                if(matriz[f][c]!=0){
                    vector[i]=matriz[f][c];
                    i++;
                }
            }
        }
    for(int f=0;f<10;f++){
        for(int c=0;c<20;c++){
            matriz[f][c]=0;
        }
    }
    col=0;
    for(i=0;i<n;i++){
        a=vector[i]/10;
        if(matriz[a][col]==0){
            matriz[a][col]=vector[i];
        }else{
                    col++;
                    matriz[a][col]=vector[i];
                    }
        }
    i=0;
    for(int f=0;f<10;f++){
        for(int c=0;c<20;c++){
            if(matriz[f][c]!=0){
                vector[i]=matriz[f][c];
            }
        }
    }
    for(int f=0;f<n;f++){
        System.out.println(vector[f]);
    }
    }
}
