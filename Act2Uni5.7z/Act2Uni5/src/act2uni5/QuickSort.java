/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package act2uni5;

import java.util.Arrays;

/**
 *
 * @author jnune
 */
public class QuickSort {

   
    public static void main(String[] args) {
     
        int numeros[]= {1,9,23,4,55,100,1,1,23};
        System.out.println("Valores antes de aplicar el metodo QuickSort"+Arrays.toString(numeros));
        quicksort(numeros,0,numeros.length-1);
        System.out.println("Valores despues del metodo Quicksort"+Arrays.toString(numeros));
        
        String[]nombres={"Cesar","Andres","Carlos","Karen","Scott"};
        System.out.println("Valores antes del metodo quicksort"+Arrays.toString(nombres));
        quicksort(nombres,0,nombres.length-1);
        System.out.println("Valores despues del metodo quicksort"+Arrays.toString(nombres));
        
    }
    
    private static int particion(int arreglo[],int izquierda, int derecha){
        int pivote = arreglo[izquierda];
        
        while(true){
            
            while(arreglo[izquierda]<pivote){
                izquierda++;
            }
            
            while(arreglo[derecha]>pivote){
                derecha--;
            }
            
            if(izquierda >= derecha){
                return derecha;
            }else{
                int temporal = arreglo[izquierda];
                arreglo[izquierda]=arreglo[derecha];
                arreglo[derecha]=temporal;
            }
            izquierda++;
            derecha--;
        }
        
    }
    
    private static void quicksort(int arreglo[],int izquierda,int derecha){
       if(izquierda<derecha){
           int indiceParticion = particion(arreglo,izquierda,derecha);
           quicksort(arreglo,izquierda,indiceParticion);
           quicksort(arreglo,indiceParticion+1,derecha);
       } 
    }
    
    
    
    private static int particion(String arreglo[],int izquierda,int derecha){
        String pivote = arreglo[izquierda];
        while(true){
            while(arreglo[izquierda].compareTo(pivote)<0){
                izquierda++;
            }
            while(arreglo[derecha].compareTo(pivote)>0){
                derecha--;
            }
            if(izquierda>=derecha){
              return derecha;  
            }else{
                String temporal = arreglo[izquierda];
                arreglo[izquierda] = arreglo[derecha];
                arreglo[derecha]=temporal;
                izquierda++;
                derecha--;
            }
            
        }
    }
    
    private static void quicksort(String arreglo[],int izquierda,int derecha){
       if(izquierda<derecha){
           int indiceParticion = particion(arreglo,izquierda,derecha);
           quicksort(arreglo,izquierda,indiceParticion);
           quicksort(arreglo,indiceParticion+1,derecha);
       } 
    }
    
}
