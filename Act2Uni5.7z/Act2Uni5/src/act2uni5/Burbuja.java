/*+1
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package act2uni5;

import java.util.Scanner;

/**
 *
 * @author jnune
 */
public class Burbuja {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int nn;
        Scanner sc = new Scanner(System.in);
        System.out.println("Defina el tamano del arreglo");
        
        nn=sc.nextInt();
        System.out.println();
        int ArrayN[]=new int[nn];
        
        for(int i=0;i<ArrayN.length;i++){
            System.out.println("Elemento asignado en indice "+(i+1));
            ArrayN[i]=sc.nextInt();
        }
        
        System.out.println("***Los elementos NO estan ordenados");
        mostrarN(ArrayN);
        
        System.out.println("Desea ordenar los elementos");
        String res = sc.nextLine();
        res = sc.nextLine();
        
        if(res.equalsIgnoreCase("S")){
            System.out.println("***Arreglo Ordenado***");
            ordenaBurbuja(ArrayN);
        }
        
    }
    
    public static void ordenaBurbuja(int ArrayN[]){
        
        for (int i=0;i<ArrayN.length-1;i++){
            for(int j=0;j<ArrayN.length-1;j++){
                if(ArrayN[j]>ArrayN[j+1]){
                    int temp=ArrayN[j+1];
                    ArrayN[j+1]=ArrayN[j];
                    ArrayN[j]=temp;
                }
            }
        }
        mostrarN(ArrayN);
    }
    
    public static void mostrarN(int ArrayN[]){
        System.out.println("************");
        
        for(int i=0;i<ArrayN.length;i++){
            System.out.println("Elemento "+(i+1)+"--->"+ArrayN[i]+"\n");
        }
        System.out.println("**********");
    }
    
}
